package it.cs.unicam.ids.filiera.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilieraAgricolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
