package it.cs.unicam.ids.filiera.demo.dtos;

public record UtenteDTO(
        String nome,
        String cognome,
        String email,
        String password
) {}
