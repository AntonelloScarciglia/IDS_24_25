package it.cs.unicam.ids.filiera.demo.dtos;

public record BundleItemDTO(
        Long prodottoId,
        int quantita
) {}
