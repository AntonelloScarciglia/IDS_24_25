package it.cs.unicam.ids.filiera.demo.observer;

import it.cs.unicam.ids.filiera.demo.entity.UtenteVerificato;
import it.cs.unicam.ids.filiera.demo.repositories.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Observer implements iObserver{

    private final UtenteRepository utenteRepository;

    public Observer(UtenteRepository utenteRepository) {
        this.utenteRepository = utenteRepository;
    }

    @Override
    public void aggiornaUtenti(String messaggio) {
        List<UtenteVerificato> utenti = utenteRepository.findAll();
        if(utenti.isEmpty()){
            throw new NullPointerException("Nessun utente registrato da notificare");
        }
        for(UtenteVerificato u : utenti){
            u.getNotifiche().add(messaggio);
            utenteRepository.save(u);
        }
    }

    @Override
    public void aggiornaUtentiInviti(Long invitatoId, String messaggio) {
        utenteRepository.findById(invitatoId).ifPresent( u -> {
            u.getNotifiche().add(messaggio);
            utenteRepository.save(u);
        });
    }
}
