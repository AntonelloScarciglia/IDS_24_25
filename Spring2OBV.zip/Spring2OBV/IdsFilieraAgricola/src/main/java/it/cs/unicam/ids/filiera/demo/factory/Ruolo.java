package it.cs.unicam.ids.filiera.demo.factory;

public enum Ruolo {
	PRODUTTORE, TRASFORMATORE, DISTRIBUTORE, ACQUIRENTE, ANIMATORE
}
