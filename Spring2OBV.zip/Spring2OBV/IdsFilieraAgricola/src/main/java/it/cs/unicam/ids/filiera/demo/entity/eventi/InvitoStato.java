package it.cs.unicam.ids.filiera.demo.entity.eventi;

public enum InvitoStato {
    ACCETTATO,
    RIFIUTATO,
    IN_ATTESA
}
