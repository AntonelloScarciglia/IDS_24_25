package it.cs.unicam.ids.filiera.demo.observer;

public interface iObserver {
    void aggiornaUtenti(String messaggio);
    void aggiornaUtentiInviti(Long invitatoId, String messaggio);
}
