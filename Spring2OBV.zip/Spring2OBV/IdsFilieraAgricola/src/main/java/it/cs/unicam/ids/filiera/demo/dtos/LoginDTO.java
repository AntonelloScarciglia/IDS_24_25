package it.cs.unicam.ids.filiera.demo.dtos;

public record LoginDTO(
        String email,
        String password
) {}
